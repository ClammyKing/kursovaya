﻿using Library.BL.Interfaces;

namespace Library.BL.Models
{
    public class ProcessFactory
    {
        public static IBookProcess GetBookProcess() // Возвращает объект, реализующий <seealso cref="IBookProcess"/>
        {
            return new BookProcessDb();
        }
    }
}
