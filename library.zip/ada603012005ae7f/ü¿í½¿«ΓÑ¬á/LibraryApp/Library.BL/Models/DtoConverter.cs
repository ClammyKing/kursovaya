﻿using Library.BL.Entities;

namespace Library.BL.Models
{
    public class DtoConverter
    {
        public static BookDto Convert(Book book)
        {
            if (book == null)
                return null;
            BookDto bookDto = new BookDto();
            bookDto.Id = book.BookId;
            bookDto.Author = book.Author;
            bookDto.Name = book.Name;
            bookDto.Reader = book.Reader;
            bookDto.IssueDate = book.IssueDate;
            bookDto.ReturnDate = book.ReturnDate;
            bookDto.Genre = book.Genre;
            return bookDto;
        }

        public static Book Convert(BookDto bookDto)
        {
            if (bookDto == null)
                return null;
            Book book = new Book(); 
            book.BookId = bookDto.Id;
            book.Author = bookDto.Author;
            book.Name = bookDto.Name;
            book.Reader = bookDto.Reader;
            book.IssueDate = bookDto.IssueDate;
            book.ReturnDate = bookDto.ReturnDate;
            book.Genre = bookDto.Genre;
            return book;
        }

        public static IList<BookDto> Convert(IList<Book> books)
        {
            if (books == null)
                return null;
            IList<BookDto> bookDtos = new List<BookDto>();
            foreach(Book book in books)
            {
                bookDtos.Add(Convert(book));
            }

            return bookDtos;
        }
    }
}
