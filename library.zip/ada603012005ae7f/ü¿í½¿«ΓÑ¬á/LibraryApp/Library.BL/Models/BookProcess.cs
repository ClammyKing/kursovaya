﻿using Library.BL.Interfaces;

namespace Library.BL.Models
{
    public class BookProcess : IBookProcess
    {
        
        private static readonly IDictionary<int, BookDto> Books = new Dictionary<int, BookDto>();       

        public IList<BookDto> GetList()
        {
            return new List<BookDto>(Books.Values);
        }

        public BookDto Get(int id)
        {
            return Books.ContainsKey(id) ? Books[id] : null;
        }

        public void Add(BookDto book)
        {
            int max = Books.Keys.Count == 0 ? 1 : Books.Keys.Max(p => p) + 1;
            book.Id = max;
            Books.Add(max, book);
        }

        public void Update(BookDto book)
        {
            if(Books.ContainsKey(book.Id))
                Books[book.Id] = book;
        }

        public void Delete(int id)
        {
            if(Books.ContainsKey(id))
                Books.Remove(id);
        }
    }
}
