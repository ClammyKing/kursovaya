﻿using Library.BL.Entities;
using Library.BL.Interfaces;
using System.Configuration;
using System.Data.SqlClient;

namespace Library.BL.Models
{
    public class BookDao : IBookDao
    {   
        public Book Get(int id) // Получение книги по ID из ДБ
        {
            using var conn = GetConnection();
            conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT BookId, Author, Name, Reader, " +
                "IssueDate, ReturnDate, Genre FROM Books WHERE BookId = @id";
            cmd.Parameters.AddWithValue("@id", id);
            using var dataReader = cmd.ExecuteReader();
            return !dataReader.Read() ? null : LoadBook(dataReader); 
        }

        public IList<Book> GetAll() // вывод списка книг из БД
        {
            IList<Book> books = new List<Book>();
            using(var conn = GetConnection()) 
            {
                conn.Open();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT BookId, Author, Name, Reader, " +
                "IssueDate, ReturnDate, Genre FROM Books";
                using var dataReader = cmd.ExecuteReader();
                while (dataReader.Read())
                {
                    books.Add(LoadBook(dataReader));
                }
            }
            return books;
        }

        public void Add(Book book) //Добавление книг и юзеров с датой когда взяли и когда должнгы вернуть
        {
            using var conn = GetConnection();
            conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "INSERT INTO Books (Author, Name, " +
                "Reader, IssueDate, ReturnDate, Genre) VALUES (@Author, @Name, @Reader, " +
                "@IssueDate, @ReturnDate, @Genre)";
            cmd.Parameters.AddWithValue("@Author", book.Author);
            cmd.Parameters.AddWithValue("@Name", book.Name);
            cmd.Parameters.AddWithValue("@Reader", book.Reader);
            cmd.Parameters.AddWithValue("@IssueDate", book.IssueDate);
            cmd.Parameters.AddWithValue("@Genre", book.Genre);
            object returnDate = book.ReturnDate.HasValue ?
                (object)book.ReturnDate.Value : DBNull.Value;
            cmd.Parameters.AddWithValue("@ReturnDate", returnDate);
            cmd.ExecuteNonQuery();
        }

        public void Update(Book book) //Обновление данных в бд библиотеки
        {
            using var conn = GetConnection();
            conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "UPDATE Books SET Author = @Author, Name = @Name, " +
                "Reader = @Reader, IssueDate = @IssueDate, ReturnDate = @ReturnDate, " +
                "Genre = @Genre WHERE BookId = @id";
            cmd.Parameters.AddWithValue("@Author", book.Author);
            cmd.Parameters.AddWithValue("@Name", book.Name);
            cmd.Parameters.AddWithValue("@Reader", book.Reader);
            cmd.Parameters.AddWithValue("@IssueDate", book.IssueDate);
            cmd.Parameters.AddWithValue("@id", book.BookId);
            cmd.Parameters.AddWithValue("@Genre", book.Genre);
            object returnDate = book.ReturnDate.HasValue ?
                (object)book.ReturnDate.Value : DBNull.Value;
            cmd.Parameters.AddWithValue("@ReturnDate", returnDate);
            cmd.ExecuteNonQuery();
        } 

        public void Delete(int id) //Удаление выбранной записи с книгой
        {
            using var conn = GetConnection();
            conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "DELETE FROM Books WHERE BookId = @id";
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
        }

        private static Book LoadBook(SqlDataReader reader)
        {
            Book book = new Book //Создание нового учёта книги
            {
                BookId = reader.GetInt32(reader.GetOrdinal("BookId")), //Заполнение пустых полей в открывшемся окне
                IssueDate = Convert.ToInt32(reader["IssueDate"])
            };
            object returnDate = reader["ReturnDate"];  
            if (returnDate != DBNull.Value)
                book.ReturnDate = Convert.ToInt32(returnDate);
            book.Author = reader.GetString(reader.GetOrdinal("Author")); // Присвоение строкам значений в новом окне
            book.Name = reader.GetString(reader.GetOrdinal("Name"));
            book.Reader = reader.GetString(reader.GetOrdinal("Reader"));
            book.Genre = reader.GetString(reader.GetOrdinal("Genre"));
            return book;
        }

        private static string GetConnectionString() // Возвращает строку подключения к базе
        {
            return ConfigurationManager.ConnectionStrings["Book"].ConnectionString;
        }
        private static SqlConnection GetConnection() //Подключение к локальной БД через путь указанный ниже
        {
            return new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\clamm\Downloads\DBase\LibraryDB.mdf;Integrated Security=True");
        }
    }
}
