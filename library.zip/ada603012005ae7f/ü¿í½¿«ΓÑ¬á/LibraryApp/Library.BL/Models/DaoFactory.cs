﻿using Library.BL.Interfaces;

namespace Library.BL.Models
{
    public class DaoFactory
    {
        public static IBookDao GetBookDao()
        {
            return new BookDao();
        }
    }
}
