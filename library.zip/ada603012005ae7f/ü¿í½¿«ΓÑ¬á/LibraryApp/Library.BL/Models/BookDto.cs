﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.BL.Models
{
    public class BookDto //Класс книг
    {
        public int Id { get; set; } // ID книги
        public string Author { get; set; } // Автор книги
        public string Name { get; set; } // Название книги
        public string Reader { get; set; } // Пользователь на которого записывают книгу
        public int IssueDate { get; set; } // Дата выдачи
        public int? ReturnDate { get; set; } // Дата возврата
        public string Genre { get; set; } // Жанр
    }
}
