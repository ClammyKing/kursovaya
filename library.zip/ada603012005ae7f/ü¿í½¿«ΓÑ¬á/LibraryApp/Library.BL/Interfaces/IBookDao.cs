﻿using Library.BL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.BL.Interfaces
{
    public interface IBookDao // Описание действий с книгой в БД
    {
        Book Get(int id); // Получить книгу по ID
        IList<Book> GetAll(); // Получить список всех книг
        void Add(Book book); // Добавить книгу
        void Update(Book book); // Редактировать книгу
        void Delete(int id); // Удалить книгу  
    }
}
