﻿using Library.BL.Models;

namespace Library.BL.Interfaces
{
    public interface IBookProcess //Декларированние данных при роботе с книгой
    {
        IList<BookDto> GetList(); // Возвращает список книг
        BookDto Get(int id); // Возвращает книгу по id. name="id" 
        void Add(BookDto book); // Добавляет книгу. name="book"
        void Update(BookDto book); // Обновляет данные о книге
        void Delete(int id); // Удаляет книгу
    }
}
