﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.BL.Entities
{
    public class Book // Таблица для БД
    {
        public int BookId; 
        public string Author;
        public string Name;
        public string Reader;
        public int IssueDate;
        public int? ReturnDate;
        public string Genre;

    }
}
