﻿using Library.BL.Interfaces;
using Library.BL.Models;
using System;
using System.Linq;
using System.Windows;

namespace Library.UI
{
    public partial class AddBooksWindow : Window
    {
        private static readonly string[] Genres = { "Фантастика", "Триллер", "Ужасы" }; // Список жанров
        private int _id; 
        public AddBooksWindow()
        {
            InitializeComponent();
            // Передаем допустимые значения
            cbGenre.ItemsSource = Genres;
            // Задаем начальное значение
            cbGenre.SelectedIndex = 0;
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e) // Кнопка закрытия окна
        {
            Close();
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e) // Кнопка добавления книги с проверкой на пустые поля
        {
            int issueDate;
            int? returnDate = null;

            if (string.IsNullOrEmpty(tbAuthor.Text))
            {
                MessageBox.Show("Поле Автор не может быть пустым", "Проверка");
                return;
            }

            if (string.IsNullOrEmpty(tbName.Text))
            {
                MessageBox.Show("Поле Название не может быть пустым", "Проверка");
                return;
            }

            if (string.IsNullOrEmpty(tbReader.Text))
            {
                MessageBox.Show("Поле Читатель не может быть пустым", "Проверка");
                return;
            }

            if (!int.TryParse(tbIssueDate.Text, out issueDate))
            {
                MessageBox.Show("Дата выдачи должна быть целым числом", "Проверка");
                return;
            }

            if (!string.IsNullOrEmpty(tbReturnDate.Text))
            {
                int intReturn;
                if (!int.TryParse(tbReturnDate.Text, out intReturn))
                {
                    MessageBox.Show("Дата возврата должна быть целым числом", "Проверка");
                    return;
                }

                if (intReturn < issueDate)
                {
                    MessageBox.Show("Дата возврата должны быть больше даты выдачи", "Проверка");
                    return;
                }
                returnDate = intReturn;
            }

            // Создание объекта для передачи данных
            BookDto book = new BookDto
            {
                // Заполнение объекта данными
                Author = tbAuthor.Text,
                Name = tbName.Text,
                Reader = tbReader.Text,
                IssueDate = issueDate,
                ReturnDate = returnDate,
                Genre = cbGenre.SelectedItem.ToString()
            };
            // Запрос на реализованную ранее задачу
            IBookProcess bookProcess = ProcessFactory.GetBookProcess();
            // если это новый объект - сохраняем его
            if (_id == 0)
            {
                bookProcess.Add(book);
            }
            else // иначе обновляем
            {
                // копируем обратно идентификатор объекта
                book.Id = _id;
                // обновляем 
                bookProcess.Update(book);
            }
            Close();
        }

        public void Load(BookDto book)
        {
            // если объект не существует, или не в списке допустимых, выход
            if (book == null || !Genres.Contains(book.Genre))
                return;
            // сохраняем id книги 
            _id = book.Id;
            // заполняем визуальные компоненты для отображения данных
            tbAuthor.Text = book.Author;
            tbName.Text = book.Name;
            tbReader.Text = book.Reader;
            tbIssueDate.Text = book.IssueDate.ToString();
            if (book.ReturnDate.HasValue)
                tbReturnDate.Text = book.ReturnDate.Value.ToString();
            
            cbGenre.SelectedItem = book.Genre;
        }
    }
}
