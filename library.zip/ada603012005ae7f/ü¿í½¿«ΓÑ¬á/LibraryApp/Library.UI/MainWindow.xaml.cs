﻿using Library.BL.Models;
using System.Windows;

namespace Library.UI
{ 
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            AddBooksWindow window = new AddBooksWindow();
            window.ShowDialog();

            // Получение списка книг и передача его на таблицу
            dgBook.ItemsSource = ProcessFactory.GetBookProcess().GetList();
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            // Получение списка книг и передача его на отображение в таблице
            dgBook.ItemsSource = ProcessFactory.GetBookProcess().GetList();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            // Получение выделенной строки с объектом книга
            BookDto item = dgBook.SelectedItem as BookDto;
            // Если пользователь ничего не выбрал, сообщаем об ошибке
            if (item == null)
            {
                MessageBox.Show("Выберите запись для удаления", "Удаление книги ");
            }
            // Подтверждение удаления книги
            MessageBoxResult result = MessageBox.Show("Удалить книгу " + item.Author + "?",
                "Удаление книги", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            // Если пользователь не подтвердил, выход
            if (result != MessageBoxResult.Yes)
            {
                return;
            }
            // Если все проверки пройдены и подтверждение получено, книга удаляется
            ProcessFactory.GetBookProcess().Delete(item.Id);
            // Перезагрузка списка книг
            BtnRefresh_Click(sender, e);
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            // Получение выделенной строки с книгой, если не выбрана строка, то сообщение об ошибке.
            if (dgBook.SelectedItem is not BookDto item)
            {
                MessageBox.Show("Выберите запись для редактирования", "Редактирование");
                return;
            }
            // Создание нового окна
            AddBooksWindow window = new AddBooksWindow();
            // Объект отправляется на редактирование
            window.Load(item);
            // Окно с данными отображается
            window.ShowDialog();
            // Перезагрузка списка книг
            BtnRefresh_Click(sender, e);
        }

        private void Exit_Click(object sender, RoutedEventArgs e) // Кнопка выхода из приложения
        {
            Close();
        }

        private void About_Click(object sender, RoutedEventArgs e) // Информация о...
        {
            
            MessageBox.Show("Программа - Интерактивная библиоткека. Создатель: Горылев Егор. \nДата создания: 12.03.2024 г.");
        }
    }
}
